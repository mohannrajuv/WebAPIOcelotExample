﻿namespace Shared.DataLayer
{
	public interface IAggregateRoot { }
}
