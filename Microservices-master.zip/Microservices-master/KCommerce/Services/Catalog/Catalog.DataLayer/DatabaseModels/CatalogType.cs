﻿using Shared.DataLayer.Models;

namespace Catalog.DataLayer.DatabaseModels
{
	public class CatalogType : Entity
	{
		public string Type { get; set; }
	}
}
