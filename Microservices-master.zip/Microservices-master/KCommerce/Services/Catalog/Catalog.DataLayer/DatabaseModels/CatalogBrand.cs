﻿using Shared.DataLayer.Models;

namespace Catalog.DataLayer.DatabaseModels
{
	public class CatalogBrand : Entity
	{
		public string Brand { get; set; }
	}
}
