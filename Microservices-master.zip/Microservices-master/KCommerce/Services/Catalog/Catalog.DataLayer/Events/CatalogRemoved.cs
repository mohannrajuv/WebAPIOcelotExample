﻿namespace Catalog.DataLayer.Events
{
	public class CatalogRemoved : CatalogAdded
	{
	}
}
